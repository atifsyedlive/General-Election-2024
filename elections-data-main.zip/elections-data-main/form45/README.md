# form45

Form-45 tabular data collected from various sources and converted into a single universal format for easy programmatic access, starting with 31 constituencies!

**Now publicly available for everyone to use at https://elections-data.vercel.app/{GITHUB PATH}!**


